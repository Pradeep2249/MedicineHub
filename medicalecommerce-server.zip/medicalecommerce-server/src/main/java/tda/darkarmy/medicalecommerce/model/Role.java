package tda.darkarmy.medicalecommerce.model;

public enum Role {
    USER, VENDOR, ADMIN
}
